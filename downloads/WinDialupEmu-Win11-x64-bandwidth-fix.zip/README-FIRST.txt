WinDialupEmu Windows 11 x64 bandwidth fix
Source: f9bac3ab7acca7222b2e2dad509e3212b8d935d3

Disconnect dial-up and stop the old emulator before replacing the EXE.
Keep your existing config.ini. Keep bundled DLLs beside vmodem.exe.
Run in an Administrator command prompt:
vmodem.exe -c config.ini -p COM4
Use your own emulator COM port if different, then connect normally.
Use Ctrl-C to exit and restore normal LAN/Wi-Fi access.

Negotiated speed now limits upload and download IPv4 data independently.
33600 bit/s = at most 4200 IPv4 bytes/s per direction, less for TCP payload.
The Ethernet adapter will continue to display its physical 1 Gbit/s link.
Full packet queues are bounded and drop excess data; control remains responsive.
All prior network fixes and WFP isolation are retained.
See bandwidth-limit.md for implementation and test scope.

Host tests and Windows cross-build passed; affected Windows speed test pending.
