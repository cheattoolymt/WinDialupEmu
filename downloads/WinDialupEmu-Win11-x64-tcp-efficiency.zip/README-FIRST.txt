WinDialupEmu Windows 11 x64 TCP efficiency correction
Source: d9ff56b34f524c0d6e569640f8abbd7f4c98c970

Disconnect dial-up and stop the emulator before replacing vmodem.exe.
Keep existing config.ini and bundled DLLs. In an Administrator CMD, clear any
previous diagnostic environment settings before starting normally:
set "SLIRP_DEBUG="
set "G_MESSAGES_DEBUG="
vmodem.exe -c config.ini -p COM4
Use your own emulator COM port if different. Do not use --trace for speed tests.
Exit with Ctrl-C to restore normal LAN/Wi-Fi access.

Retains bandwidth limits, priority handling and network fixes.
Avoids forwarding duplicate TCP byte ranges already waiting in the queue.
Adds bounded capacity for an initial TCP window to avoid artificial losses.
Reports aggregate link rate, queue size, drops and coalesced duplicates every
10 seconds in vmodem.log. Aggregate rate includes ALL applications.

Local 100KB real TCP test: 24.526 seconds, 4077 bytes/s, zero drops.
This is a Linux host result, not a guarantee of the affected Windows speed.
See bandwidth-limit.md for validation and limitations.
