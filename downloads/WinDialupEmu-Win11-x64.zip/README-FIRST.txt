WinDialupEmu - Windows 11 x64 test build
Source: 0600952f8d02249cb6db830be764cdc0e7224cc4 (original repository main)

Extract ALL files into one folder, keeping the DLL files next to vmodem.exe.
Keep your current config.ini if you already have a working setup.
Open Command Prompt as Administrator, switch to this folder, then run:
  vmodem.exe -c config.ini -p CNCB0
CNCB0 must be the emulator side of your com0com pair.
Then connect using your Windows dial-up connection.
Default phone number: 0120-000-0000
Enable "Use default gateway on remote network" in the RAS IPv4 settings.

Network isolation is active while vmodem.exe is running, even before dialing.
Close with Ctrl-C to restore normal LAN/Wi-Fi application access.
Logs: vmodem.log (default config).

Includes the original Internet NAT/routing/DNS and WFP isolation changes.
The XP-specific audio and diagnostic changes are not included.
Cross-build and host tests passed. Actual Windows 11/RAS behavior needs testing.
