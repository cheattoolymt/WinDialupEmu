WinDialupEmu Windows 11 x64 congestion correction
Source: 9e4ae3cf3f6e06c8206dd820531c89b9f85f7130

Disconnect dial-up and stop the old emulator before replacing vmodem.exe.
Keep your existing config.ini. Keep bundled DLLs beside vmodem.exe.
Run in an Administrator command prompt:
vmodem.exe -c config.ini -p COM4
Use your own emulator COM port if different, then connect normally.
Exit with Ctrl-C to restore LAN/Wi-Fi access.

Retains negotiated upload/download bandwidth limits and existing network fixes.
Fixes the small-FIFO congestion regression: DNS and TCP control/ACK traffic
have reserved capacity and priority, using the SAME bit budget as bulk data.
Bulk flows share service; new connections can enter saturated queues.
Unsupported LAN discovery multicast/broadcast no longer consumes uplink budget.
See bandwidth-limit.md for details and limitations.

Host congestion, real modem/NAT/PPP/serial integration, existing regression
and Windows x64 build checks passed. Affected Windows browsing test pending.
