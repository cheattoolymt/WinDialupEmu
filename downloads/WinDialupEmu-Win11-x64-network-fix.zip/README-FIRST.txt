WinDialupEmu Windows 11 x64 network audit build
Source: 2112455499d3a9a2cb863eeb7123f7103762269b

Stop the old emulator, disconnect dial-up, and extract ALL files together.
Keep your existing config.ini. Run in an Administrator command prompt:
vmodem.exe -c config.ini -p COM4
Then connect normally. Use your own emulator COM port if different.
Use Ctrl-C to exit and restore normal LAN/Wi-Fi access.

Fixes COM idle-read CPU spin and propagation of serial/WSAPoll errors.
Detects changes to the physical IPv4 DisableDefaultRoutes flag after RAS
connects and restores the pre-start value while keeping WFP isolation.
Does not add routes or change metrics/DNS. Refuses pre-existing disabled policy.
The log states initial flag and whether route eligibility was restored.

See network-audit.md for full evidence, scope and remaining limitations.
IPv6 PPP is unsupported; system DNS selection is not rewritten.
Host tests and Windows cross-build passed; affected Windows retest pending.
